var classAMPS_1_1StoreImpl =
[
    [ "StoreImpl", "classAMPS_1_1StoreImpl.html#ae6dffba99210c30facc396491f271e77", null ],
    [ "discardUpTo", "classAMPS_1_1StoreImpl.html#a3a391f99cd236d3a2370638596e96063", null ],
    [ "flush", "classAMPS_1_1StoreImpl.html#a4405a4c73ea6dc3df17b5663d191cc8e", null ],
    [ "getLastPersisted", "classAMPS_1_1StoreImpl.html#a24fd9abeba9620f7d515b0933fc0afb8", null ],
    [ "getLowestUnpersisted", "classAMPS_1_1StoreImpl.html#af5060827d0e062282e1dbf25cbc2a2e3", null ],
    [ "replay", "classAMPS_1_1StoreImpl.html#ac3326d25b8aa2df5a93db3629b60cc21", null ],
    [ "replaySingle", "classAMPS_1_1StoreImpl.html#ada24473da48fd544d789b7ec2dac7d08", null ],
    [ "setResizeHandler", "classAMPS_1_1StoreImpl.html#af38461a40772ee3147546e0e6132eea4", null ],
    [ "store", "classAMPS_1_1StoreImpl.html#a76e41f2c8c132c63ed560135949cd220", null ],
    [ "unpersistedCount", "classAMPS_1_1StoreImpl.html#a6ba03a337bf6cc5ce6545fca968ff226", null ]
];