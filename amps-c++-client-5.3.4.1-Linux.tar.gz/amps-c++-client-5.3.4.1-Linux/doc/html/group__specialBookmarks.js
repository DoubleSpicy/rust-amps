var group__specialBookmarks =
[
    [ "AMPS_BOOKMARK_EPOCH", "group__specialBookmarks.html#ga9b906ecdf1afe8a265183dbe0856959a", null ],
    [ "AMPS_BOOKMARK_NOW", "group__specialBookmarks.html#ga56a5f968956ad81c7ebb864816c55a01", null ],
    [ "AMPS_BOOKMARK_RECENT", "group__specialBookmarks.html#ga9dc6d653c4c409720e685038051c7460", null ]
];