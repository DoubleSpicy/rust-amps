var classAMPS_1_1Store =
[
    [ "discardUpTo", "classAMPS_1_1Store.html#a7ec3c52b0f3d54454f55d8ccb071151c", null ],
    [ "flush", "classAMPS_1_1Store.html#ab074d36fc26325c59630e90c5bd871b4", null ],
    [ "get", "classAMPS_1_1Store.html#a0ec6dc4d797cb1e7f5ed68183c38d9c4", null ],
    [ "getErrorOnPublishGap", "classAMPS_1_1Store.html#aa2c8054f0f9cbd6728122a43a9aeb53f", null ],
    [ "getLastPersisted", "classAMPS_1_1Store.html#a5cf5ab022849a4bc25c5d4f75653cf8b", null ],
    [ "getLowestUnpersisted", "classAMPS_1_1Store.html#a928e1a334e213cb4d00a113e85984d52", null ],
    [ "isValid", "classAMPS_1_1Store.html#a3302f995710b33a7d16b715e7e2bd7ac", null ],
    [ "replay", "classAMPS_1_1Store.html#a061742652521bbbf91709703cd75f8cc", null ],
    [ "replaySingle", "classAMPS_1_1Store.html#ac715c8dd8436c4c484e53a31668366a0", null ],
    [ "setErrorOnPublishGap", "classAMPS_1_1Store.html#ac7f5bd02d664786a067b1cf8b54728fa", null ],
    [ "setResizeHandler", "classAMPS_1_1Store.html#ab267b150a870f650ea5f3a5b6c6aac01", null ],
    [ "store", "classAMPS_1_1Store.html#acb06fbca0f83c7c4dfc91662b9149dba", null ],
    [ "unpersistedCount", "classAMPS_1_1Store.html#ac936fdf868fb74571577f3f6f9251930", null ]
];