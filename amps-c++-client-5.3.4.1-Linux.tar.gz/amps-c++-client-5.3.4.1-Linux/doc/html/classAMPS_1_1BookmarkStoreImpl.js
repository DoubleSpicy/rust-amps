var classAMPS_1_1BookmarkStoreImpl =
[
    [ "discard", "classAMPS_1_1BookmarkStoreImpl.html#a7e346096895873e90c5e8f8fad83d0d8", null ],
    [ "discard", "classAMPS_1_1BookmarkStoreImpl.html#adb626d90196064248003e21e9c594893", null ],
    [ "getMaxSubIdLength", "classAMPS_1_1BookmarkStoreImpl.html#a1fa427f2fe9bc3f68f2c6b75402eb756", null ],
    [ "getMostRecent", "classAMPS_1_1BookmarkStoreImpl.html#a8ab6a919c83b203065baefe4519b3e04", null ],
    [ "getOldestBookmarkSeq", "classAMPS_1_1BookmarkStoreImpl.html#a1f068edf845f5aa203e67a83fa2a6bea", null ],
    [ "isDiscarded", "classAMPS_1_1BookmarkStoreImpl.html#a7daf3c54e66608f7d1c2e54de5684f1a", null ],
    [ "log", "classAMPS_1_1BookmarkStoreImpl.html#acd55ee0dc49ea07d312867ca5eb03f96", null ],
    [ "persisted", "classAMPS_1_1BookmarkStoreImpl.html#af38a5144ce75577c7b0fc9732dd83704", null ],
    [ "persisted", "classAMPS_1_1BookmarkStoreImpl.html#a269459f6235ef7cab7de68ea16894dac", null ],
    [ "purge", "classAMPS_1_1BookmarkStoreImpl.html#a0457f4f9095b3834cfd25ca41df153fe", null ],
    [ "purge", "classAMPS_1_1BookmarkStoreImpl.html#aec102c62bd1d2e9b45356e02cc6fa1a8", null ],
    [ "setMaxSubIdLength", "classAMPS_1_1BookmarkStoreImpl.html#a7e4cf0a381eae71b4ca53138851004b5", null ],
    [ "setResizeHandler", "classAMPS_1_1BookmarkStoreImpl.html#a4857228cb69941db5ff477a991ae2419", null ],
    [ "setServerVersion", "classAMPS_1_1BookmarkStoreImpl.html#a54cf296b8f49bd03bcb6eda6334854f8", null ],
    [ "setServerVersion", "classAMPS_1_1BookmarkStoreImpl.html#a0269c04e58c3b1b8d2d9eb371072f9cd", null ]
];