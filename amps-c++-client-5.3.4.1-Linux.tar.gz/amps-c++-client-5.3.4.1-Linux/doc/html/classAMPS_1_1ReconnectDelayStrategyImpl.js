var classAMPS_1_1ReconnectDelayStrategyImpl =
[
    [ "getConnectWaitDuration", "classAMPS_1_1ReconnectDelayStrategyImpl.html#ae4d314f0cbbeed59e0439a171a2748a9", null ],
    [ "reset", "classAMPS_1_1ReconnectDelayStrategyImpl.html#a119bc53328d5b4282851cdcd462ec638", null ]
];