var classAMPS_1_1LoggedBookmarkStore =
[
    [ "LoggedBookmarkStore", "classAMPS_1_1LoggedBookmarkStore.html#a3adb89c1e853a8ab24c2c6526910654d", null ],
    [ "LoggedBookmarkStore", "classAMPS_1_1LoggedBookmarkStore.html#af7d24988234be88b462ccddeb6e2c05a", null ],
    [ "LoggedBookmarkStore", "classAMPS_1_1LoggedBookmarkStore.html#adb2710bbf7ea2ddf2131761d7d880558", null ],
    [ "LoggedBookmarkStore", "classAMPS_1_1LoggedBookmarkStore.html#a316e3f8040f0221999ab5afc7c5883c9", null ],
    [ "discard", "classAMPS_1_1LoggedBookmarkStore.html#a68492f66a852ee5f4965357ef4208587", null ],
    [ "discard", "classAMPS_1_1LoggedBookmarkStore.html#ae4cf0419fa46b951a4e30fc4de556662", null ],
    [ "getMostRecent", "classAMPS_1_1LoggedBookmarkStore.html#aac64e4fdaf6504fd1924d35228ca4c2c", null ],
    [ "isDiscarded", "classAMPS_1_1LoggedBookmarkStore.html#a59fb23a36970755c45aae6f965853a29", null ],
    [ "log", "classAMPS_1_1LoggedBookmarkStore.html#a3e44c4dd9a3add7483c38adf521bb90c", null ],
    [ "purge", "classAMPS_1_1LoggedBookmarkStore.html#ae24cf118f854b99d8a1df80b1d607c5f", null ],
    [ "purge", "classAMPS_1_1LoggedBookmarkStore.html#a06678abc1740715995d552aa6df62d5c", null ],
    [ "setServerVersion", "classAMPS_1_1LoggedBookmarkStore.html#ab20eba3918fd30dadd68cc4c83e122d4", null ],
    [ "setServerVersion", "classAMPS_1_1LoggedBookmarkStore.html#a62302a9ef6202d894cfc04dacdf5fa02", null ]
];