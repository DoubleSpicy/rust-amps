var classAMPS_1_1BookmarkStore =
[
    [ "BookmarkStore", "classAMPS_1_1BookmarkStore.html#ab669112a1f0a699c3feafecc193f05a5", null ],
    [ "BookmarkStore", "classAMPS_1_1BookmarkStore.html#a559515d48067ed7f91a19b00844aa1bd", null ],
    [ "discard", "classAMPS_1_1BookmarkStore.html#a4d9b0e300e15e63999aad696c00b04c8", null ],
    [ "discard", "classAMPS_1_1BookmarkStore.html#a22c01fff8146ebf005265958477cce0f", null ],
    [ "get", "classAMPS_1_1BookmarkStore.html#ab3463f69d9afcf2b9fc2fcd2a9a92dbc", null ],
    [ "getMaxSubIdLength", "classAMPS_1_1BookmarkStore.html#a3584e87822dc72a1b7ea465a4b8a74b3", null ],
    [ "getMostRecent", "classAMPS_1_1BookmarkStore.html#aec9e0485c22cf800e90327bcb5ac01a9", null ],
    [ "getOldestBookmarkSeq", "classAMPS_1_1BookmarkStore.html#a6dbc7062d067769d7da29e56763de943", null ],
    [ "getOldestBookmarkSeq", "classAMPS_1_1BookmarkStore.html#a185a82aa34e6d5ab0d38fb5be0152c4f", null ],
    [ "isDiscarded", "classAMPS_1_1BookmarkStore.html#aaea091a8f2d2ee5095f4742e3903d6b1", null ],
    [ "log", "classAMPS_1_1BookmarkStore.html#a502ac677f4ceea04e19b4cdd820c876c", null ],
    [ "persisted", "classAMPS_1_1BookmarkStore.html#a73ade06e341e7e694cbe756a1c6ab187", null ],
    [ "persisted", "classAMPS_1_1BookmarkStore.html#a477bc5bd46c6058f17df3c87326e5ecf", null ],
    [ "prune", "classAMPS_1_1BookmarkStore.html#a2eae9e267b9d441965865f37145040fe", null ],
    [ "purge", "classAMPS_1_1BookmarkStore.html#a11c596327f9dda90c9db06debace705b", null ],
    [ "purge", "classAMPS_1_1BookmarkStore.html#a74834bd6579c0c0360a41d39b8e5871d", null ],
    [ "setImplementation", "classAMPS_1_1BookmarkStore.html#a730da10c292aeed8dd99c7fa9c9059ed", null ],
    [ "setMaxSubIdLength", "classAMPS_1_1BookmarkStore.html#a6822fe20a6276ab0d7875017f1bc38ea", null ],
    [ "setResizeHandler", "classAMPS_1_1BookmarkStore.html#a07f95ecff90445b4093fa7155fa5dd8a", null ],
    [ "setServerVersion", "classAMPS_1_1BookmarkStore.html#a1111ca27840fa8b321f0b47ff0e99b88", null ],
    [ "setServerVersion", "classAMPS_1_1BookmarkStore.html#a081123a456076a3c05731528be66022c", null ]
];