var classAMPS_1_1SubscriptionManager =
[
    [ "clear", "classAMPS_1_1SubscriptionManager.html#a9950bf7340a3bd7715d772807422a919", null ],
    [ "resubscribe", "classAMPS_1_1SubscriptionManager.html#a17e9d3c047bfbd33fc0b0d469bda6795", null ],
    [ "setFailedResubscribeHandler", "classAMPS_1_1SubscriptionManager.html#a763d96b233fdbccc2261a4b9312c7eac", null ],
    [ "subscribe", "classAMPS_1_1SubscriptionManager.html#a44ebcbd915bb896622f50fd131aec764", null ],
    [ "unsubscribe", "classAMPS_1_1SubscriptionManager.html#a953ee648e92c60e94af36885738c046d", null ]
];