var searchData=
[
  ['amps_5fresult',['amps_result',['../amps_8h.html#a684390c2bf8c56d49e8e2d4dc715bb04',1,'amps.h']]]
];
