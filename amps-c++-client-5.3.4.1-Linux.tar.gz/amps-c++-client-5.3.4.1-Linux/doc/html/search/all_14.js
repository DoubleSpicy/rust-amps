var searchData=
[
  ['zero',['zero',['../classAMPS_1_1Buffer.html#a54bbd74f453450aca78a8da279ed1074',1,'AMPS::Buffer::zero()'],['../classAMPS_1_1MemoryStoreBuffer.html#a6987fb5bdc0e0be553fe8a1ac2992399',1,'AMPS::MemoryStoreBuffer::zero()']]]
];
