var searchData=
[
  ['special_20bookmark_20values',['Special Bookmark Values',['../group__specialBookmarks.html',1,'']]],
  ['synchronous_20message_20processing',['Synchronous Message Processing',['../group__sync.html',1,'']]]
];
