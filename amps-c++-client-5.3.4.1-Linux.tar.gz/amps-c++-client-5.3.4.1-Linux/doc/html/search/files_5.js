var searchData=
[
  ['loggedbookmarkstore_2ehpp',['LoggedBookmarkStore.hpp',['../LoggedBookmarkStore_8hpp.html',1,'']]]
];
