var searchData=
[
  ['amps_20c_20_26_20c_2b_2b_20client_20reference',['AMPS C &amp; C++ Client Reference',['../index.html',1,'']]]
];
