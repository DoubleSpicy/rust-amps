var searchData=
[
  ['amps_5fhandle',['amps_handle',['../amps_8h.html#acfa1278412265f3b4c421e77111ed2ce',1,'amps.h']]],
  ['amps_5fthread_5fcreated_5fcallback',['amps_thread_created_callback',['../amps_8h.html#a84547b45700e098324ea8d78641a6036',1,'amps.h']]],
  ['amps_5ftransport_5ffilter_5ffunction',['amps_transport_filter_function',['../amps_8h.html#ad41bd414e658417575019135a09acf55',1,'amps.h']]]
];
