var searchData=
[
  ['wait',['wait',['../classAMPS_1_1BlockStore.html#af3e3dfabf88b098c7ba06896cf1bcdd2',1,'AMPS::BlockStore::wait()'],['../classAMPS_1_1BlockStore.html#aa462382ca943e7138d7bda173ca3ba74',1,'AMPS::BlockStore::wait(long timeout_)']]]
];
