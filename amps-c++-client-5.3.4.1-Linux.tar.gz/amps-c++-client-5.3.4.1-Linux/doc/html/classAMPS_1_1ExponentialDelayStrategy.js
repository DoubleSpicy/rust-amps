var classAMPS_1_1ExponentialDelayStrategy =
[
    [ "ExponentialDelayStrategy", "classAMPS_1_1ExponentialDelayStrategy.html#a52c5a03916c2aef7719ee4343368e885", null ],
    [ "getConnectWaitDuration", "classAMPS_1_1ExponentialDelayStrategy.html#aa67e673cf5edee34ce2baa2891ee9260", null ],
    [ "reset", "classAMPS_1_1ExponentialDelayStrategy.html#a16e2b6d3065b51cac31e8b5a52aefba2", null ]
];